#version 150

uniform sampler2D Sampler0;
uniform vec4 ColorModulator;

in vec4 vertexColor;
in vec2 texCoord0;

out vec4 fragColor;


void main() {
    vec4 defaultColor = texture(Sampler0, texCoord0);
    vec4 color = defaultColor * vertexColor;

    fragColor = color * ColorModulator;
}