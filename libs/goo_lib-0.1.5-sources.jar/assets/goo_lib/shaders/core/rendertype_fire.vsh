#version 150

in vec3 Position;
in vec4 Color;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

out vec4 vertexColor;
out vec3 localPos; // <-- NEW: Passes local model coordinates to the fragment shader

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    vertexColor = Color;
    localPos = Position; // <-- Capture raw vertex coordinate before camera matrices
}