package com.goo.goo_lib.common.event;

import com.goo.goo_lib.common.GooLib;
import com.goo.goo_lib.common.event.custom.LivingDodgeEvent;
import com.goo.goo_lib.common.registry.GLAttachments;
import com.goo.goo_lib.common.registry.GLAttributes;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ProjectileWeaponItem;
import net.minecraft.world.item.TridentItem;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.GrindstoneEvent;
import net.neoforged.neoforge.event.entity.EntityAttributeModificationEvent;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.entity.living.*;
import net.neoforged.neoforge.event.entity.player.CriticalHitEvent;
import net.neoforged.neoforge.event.level.BlockDropsEvent;

import java.util.Objects;

@EventBusSubscriber(modid = GooLib.MOD_ID)
public class GLAttributeEvents {

    @SubscribeEvent
    public static void addAttributes(EntityAttributeModificationEvent event) {
        for (EntityType<? extends LivingEntity> type : event.getTypes()) {
            if (!event.has(type, GLAttributes.LAVA_MOVEMENT_EFFICIENCY)) {
                event.add(type, GLAttributes.LAVA_MOVEMENT_EFFICIENCY);
            }
            if (!event.has(type, GLAttributes.LIFESTEAL)) {
                event.add(type, GLAttributes.LIFESTEAL);
            }
            if (!event.has(type, GLAttributes.ARROW_GRAVITY)) {
                event.add(type, GLAttributes.ARROW_GRAVITY);
            }
            if (!event.has(type, GLAttributes.ARROW_DAMAGE)) {
                event.add(type, GLAttributes.ARROW_DAMAGE);
            }
            if (!event.has(type, GLAttributes.ARROW_VELOCITY)) {
                event.add(type, GLAttributes.ARROW_VELOCITY);
            }
            if (!event.has(type, GLAttributes.DRAW_SPEED)) {
                event.add(type, GLAttributes.DRAW_SPEED);
            }
            if (!event.has(type, GLAttributes.HEALING_RECEIVED)) {
                event.add(type, GLAttributes.HEALING_RECEIVED);
            }
            if (!event.has(type, GLAttributes.FRICTION_MODIFIER)) {
                event.add(type, GLAttributes.FRICTION_MODIFIER);
            }
            if (!event.has(type, GLAttributes.AIR_DRAG_MODIFIER)) {
                event.add(type, GLAttributes.AIR_DRAG_MODIFIER);
            }
            if (!event.has(type, GLAttributes.BOAT_SPEED_MODIFIER)) {
                event.add(type, GLAttributes.BOAT_SPEED_MODIFIER);
            }
            if (!event.has(type, GLAttributes.CLIMBING_SPEED_MODIFIER)) {
                event.add(type, GLAttributes.CLIMBING_SPEED_MODIFIER);
            }
            if (!event.has(type, GLAttributes.WALL_CLIMBING)) {
                event.add(type, GLAttributes.WALL_CLIMBING);
            }
            if (!event.has(type, GLAttributes.STEALTH)) {
                event.add(type, GLAttributes.STEALTH);
            }
            if (!event.has(type, GLAttributes.DODGE_CHANCE)) {
                event.add(type, GLAttributes.DODGE_CHANCE);
            }
            if (!event.has(type, GLAttributes.INVULNERABILITY_TICKS)) {
                event.add(type, GLAttributes.INVULNERABILITY_TICKS);
            }
        }

        if (!event.has(EntityType.PLAYER, GLAttributes.VILLAGER_REPUTATION)) {
            event.add(EntityType.PLAYER, GLAttributes.VILLAGER_REPUTATION);
        }
        if (!event.has(EntityType.PLAYER, GLAttributes.RIGHT_CLICK_DELAY)) {
            event.add(EntityType.PLAYER, GLAttributes.RIGHT_CLICK_DELAY);
        }
        if (!event.has(EntityType.PLAYER, GLAttributes.CRITICAL_DAMAGE)) {
            event.add(EntityType.PLAYER, GLAttributes.CRITICAL_DAMAGE);
        }
        if (!event.has(EntityType.PLAYER, GLAttributes.XP_GAIN)) {
            event.add(EntityType.PLAYER, GLAttributes.XP_GAIN);
        }
        if (!event.has(EntityType.PLAYER, GLAttributes.ELYTRA_ACCELERATION_MODIFIER)) {
            event.add(EntityType.PLAYER, GLAttributes.ELYTRA_ACCELERATION_MODIFIER);
        }


    }

    @SubscribeEvent
    public static void onEntityJoinWorld(EntityJoinLevelEvent event) {
        if (!event.getLevel().isClientSide()) {
            if (event.getEntity() instanceof Projectile projectile) {
                if (projectile.getOwner() instanceof LivingEntity owner) {

                    if (owner.getAttributes().hasAttribute(GLAttributes.ARROW_GRAVITY)) {
                        projectile.setData(GLAttachments.ARROW_GRAVITY,
                                (float) Objects.requireNonNull(owner.getAttribute(GLAttributes.ARROW_GRAVITY)).getValue());
                    }

                    if (owner.getAttributes().hasAttribute(GLAttributes.ARROW_DAMAGE) && projectile instanceof AbstractArrow arrow) {
                        arrow.setBaseDamage(arrow.getBaseDamage() * owner.getAttributeValue(GLAttributes.ARROW_DAMAGE));
                    }

                }
            }
        }
    }

    @SubscribeEvent
    public static void onLivingHurtPost(LivingDamageEvent.Post event) {
        DamageSource source = event.getSource();

        // Lifesteal
        if (source.is(DamageTypes.PLAYER_ATTACK) || source.is(DamageTypes.MOB_ATTACK) || source.is(DamageTypes.MOB_ATTACK_NO_AGGRO)) {
            if (source.getDirectEntity() == source.getEntity()) {
                if (source.getEntity() instanceof LivingEntity livingEntity)
                    livingEntity.heal((float) (event.getNewDamage() * livingEntity.getAttributeValue(GLAttributes.LIFESTEAL)));
            }
        }
    }

    @SubscribeEvent
    public static void onCrit(CriticalHitEvent event) {
        if (event.isVanillaCritical()) {
            event.setDamageMultiplier((float) (event.getEntity().getAttributeValue(GLAttributes.CRITICAL_DAMAGE)));
        }
    }

    private static boolean canBenefitFromDrawSpeed(ItemStack stack) {
        return stack.getItem() instanceof ProjectileWeaponItem || stack.getItem() instanceof TridentItem;
    }

    /**
     * This event handler is the implementation for {@link GLAttributes#DRAW_SPEED}.<br>
     * Each full point of draw speed provides an extra using tick per game tick.<br>
     * Each partial point of draw speed provides an extra using tick periodically.<br>
     * Adapted from <a href="https://github.com/Shadows-of-Fire/Apothic-Attributes/blob/1.21/src/main/java/dev/shadowsoffire/apothic_attributes/impl/AttributeEvents.java#L74">Apotheosis</a>
     */
    @SubscribeEvent
    public static void drawSpeed(LivingEntityUseItemEvent.Tick e) {
        LivingEntity livingEntity = e.getEntity();
        double drawSpeed = livingEntity.getAttributeValue(GLAttributes.DRAW_SPEED);
        if (drawSpeed <= 1.0 || !canBenefitFromDrawSpeed(e.getItem())) return;

        // Fast draw logic remains safe and smooth because it accelerates the countdown downward
        double t = drawSpeed - 1.0;
        int extraTicks = (int) t;
        t -= extraTicks;

        if (extraTicks > 0) {
            e.setDuration(e.getDuration() - extraTicks);
        }
        if (t > 0) {
            int mod = (int) Math.ceil(1.0 / t);
            if (livingEntity.tickCount % mod == 0) {
                e.setDuration(e.getDuration() - 1);
            }
        }
    }

    @SubscribeEvent
    public static void onLivingHeal(LivingHealEvent event) {
        if (event.getEntity() instanceof Player player) {
            event.setAmount((float) (event.getAmount() * player.getAttributeValue(GLAttributes.HEALING_RECEIVED)));
            if (event.getAmount() <= 0) event.setCanceled(true);
        }
    }

    /**
     * Handles {@link GLAttributes#XP_GAIN}
     */

    @SubscribeEvent
    public static void onMobDropExp(LivingExperienceDropEvent event) {
        if (event.getAttackingPlayer() != null) {
            event.setDroppedExperience((int) (event.getDroppedExperience() * event.getAttackingPlayer().getAttributeValue(GLAttributes.XP_GAIN)));
        }
    }

    @SubscribeEvent
    public static void onBlockDrops(BlockDropsEvent event) {
        if (event.getBreaker() instanceof Player player) {
            event.setDroppedExperience((int) (event.getDroppedExperience() * player.getAttributeValue(GLAttributes.XP_GAIN)));
        }
    }

    @SubscribeEvent
    public static void onGrindstone(GrindstoneEvent.OnTakeItem event) {
        if (event.getPlayer() != null)
            event.setXp((int) (event.getXp() * event.getPlayer().getAttributeValue(GLAttributes.XP_GAIN)));
    }

    @SubscribeEvent
    public static void onLivingVisibility(LivingEvent.LivingVisibilityEvent event) {
        event.modifyVisibility(1 - event.getEntity().getAttributeValue(GLAttributes.STEALTH));
    }

    @SubscribeEvent
    public static void onLivingIncomingDamage(LivingIncomingDamageEvent event) {
        LivingEntity dodger = event.getEntity();
        double baseDodgeChance = dodger.getAttributeValue(GLAttributes.DODGE_CHANCE);
        double initialRoll = dodger.getRandom().nextDouble();

        LivingDodgeEvent.Pre preEvent = new LivingDodgeEvent.Pre(
                dodger, initialRoll, baseDodgeChance, event.getSource(), event.getContainer()
        );
        NeoForge.EVENT_BUS.post(preEvent);

        // if pre canceled, immediately return without canceling damage
        if (preEvent.isCanceled()) {
            return;
        }

        // roll
        if (preEvent.getRoll() <= preEvent.getDodgeChance()) {
            // cancel damage
            event.setCanceled(true);

            // post event to notify of successful dodge
            LivingDodgeEvent.Post postEvent = new LivingDodgeEvent.Post(
                    dodger, preEvent.getRoll(), preEvent.getDodgeChance(), event.getSource(), event.getContainer()
            );
            NeoForge.EVENT_BUS.post(postEvent);
        }

        event.getContainer().setPostAttackInvulnerabilityTicks((int) dodger.getAttributeValue(GLAttributes.INVULNERABILITY_TICKS));

    }
}
