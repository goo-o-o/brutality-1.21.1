package com.goo.goo_lib.common.registry;

import com.goo.goo_lib.common.GooLib;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.RangedAttribute;
import net.neoforged.neoforge.common.BooleanAttribute;
import net.neoforged.neoforge.common.PercentageAttribute;
import net.neoforged.neoforge.registries.DeferredRegister;

public class GLAttributes {
    public static final DeferredRegister<Attribute> ATTRIBUTES = DeferredRegister.create(
            BuiltInRegistries.ATTRIBUTE, GooLib.MOD_ID);

    private static String prepend(String name){
        return "attributes." + GooLib.MOD_ID + "." + name;
    }

    public static final Holder<Attribute> FISHING_LUCK = ATTRIBUTES.register("fishing_luck", () -> new RangedAttribute(
            prepend("fishing_luck"),
            0, -10000, 10000
    ));
    public static final Holder<Attribute> FISHING_BOBBER_COUNT = ATTRIBUTES.register("fishing_bobber_count", () -> new RangedAttribute(
            prepend("fishing_bobber_count"),
            1, 0, 10000
    ));

    public static final Holder<Attribute> VILLAGER_REPUTATION = ATTRIBUTES.register("villager_reputation", () -> new RangedAttribute(
            prepend("villager_reputation"),
            0, -10000, 10000
    ));

    public static final Holder<Attribute> RIGHT_CLICK_DELAY = ATTRIBUTES.register("right_click_delay", () -> new RangedAttribute(
            prepend("right_click_delay"),
            4, 0, 1024
    ).setSyncable(true).setSentiment(Attribute.Sentiment.NEGATIVE));

    public static final Holder<Attribute> LAVA_MOVEMENT_EFFICIENCY = ATTRIBUTES.register("lava_movement_efficiency", () -> new PercentageAttribute(
            prepend("lava_movement_efficiency"),
            0, 0.0, 1.0
    ).setSyncable(true));

    public static final Holder<Attribute> LIFESTEAL = ATTRIBUTES.register("lifesteal", () -> new PercentageAttribute(
            prepend("lifesteal"),
            0, 0, 10000
    ));
    public static final Holder<Attribute> DRAW_SPEED = ATTRIBUTES.register("draw_speed", () -> new PercentageAttribute(
            prepend("draw_speed"),
            1, 0.01, 10000
    ).setSyncable(true));

    public static final Holder<Attribute> ARROW_VELOCITY = ATTRIBUTES.register("arrow_velocity", () -> new PercentageAttribute(
            prepend("arrow_velocity"),
            1, 0.01, 10000
    ));
    public static final Holder<Attribute> ARROW_DAMAGE = ATTRIBUTES.register("arrow_damage", () -> new PercentageAttribute(
            prepend("arrow_damage"),
            1, 0.01, 10000
    ));

    public static final Holder<Attribute> ARROW_GRAVITY = ATTRIBUTES.register("arrow_gravity", () -> new PercentageAttribute(
            prepend("arrow_gravity"),
            1, -10000, 10000
    ).setSyncable(true));

    public static final Holder<Attribute> ARROW_KNOCKBACK = ATTRIBUTES.register("arrow_knockback", () -> new PercentageAttribute(
            prepend("arrow_knockback"),
            1, 0, 10000
    ));

    public static final Holder<Attribute> CRITICAL_DAMAGE = ATTRIBUTES.register("critical_damage", () -> new PercentageAttribute(
            prepend("critical_damage"),
            1.5, 0, 10000
    ));

    public static final Holder<Attribute> XP_GAIN = ATTRIBUTES.register("xp_gain", () -> new PercentageAttribute(
            prepend("xp_gain"),
            1, 0, 10000
    ));

    public static final Holder<Attribute> INVULNERABILITY_TICKS = ATTRIBUTES.register("invulnerability_ticks", () -> new RangedAttribute(
            prepend("invulnerability_ticks"),
            20, 0, 10000
    ));

    public static final Holder<Attribute> HEALING_RECEIVED = ATTRIBUTES.register("healing_received", () -> new PercentageAttribute(
            prepend("healing_received"),
            1, 0, 10000
    ));

    public static final Holder<Attribute> FRICTION_MODIFIER = ATTRIBUTES.register("friction_modifier", () -> new PercentageAttribute(
            prepend("friction_modifier"),
            1, 0, 10000
    ).setSyncable(true).setSentiment(Attribute.Sentiment.NEUTRAL));


    public static final Holder<Attribute> AIR_DRAG_MODIFIER = ATTRIBUTES.register("air_drag_modifier", () -> new PercentageAttribute(
            prepend("air_drag_modifier"),
            1, 0, 10000
    ).setSyncable(true).setSentiment(Attribute.Sentiment.NEUTRAL));

    /**
     * Entity visibility percentage from hostile mobs.
     */
    public static final Holder<Attribute> STEALTH = ATTRIBUTES.register("stealth", () ->
            new PercentageAttribute(prepend("stealth"), 0, 0, 1)
                    .setSyncable(true));

    public static final Holder<Attribute> DODGE_CHANCE = ATTRIBUTES.register("dodge_chance", () ->
            new PercentageAttribute(prepend("dodge_chance"), 0, 0, 1)
                    .setSyncable(true));


    public static final Holder<Attribute> BOAT_SPEED_MODIFIER = ATTRIBUTES.register("boat_speed_modifier", () -> new PercentageAttribute(
            prepend("boat_speed_modifier"),
            1, 0, 1000
    ).setSyncable(true));

    public static final Holder<Attribute> WALL_CLIMBING = ATTRIBUTES.register("wall_climbing", () -> new BooleanAttribute(
            prepend("wall_climbing"),
            false
    ).setSyncable(true));

    public static final Holder<Attribute> CLIMBING_SPEED_MODIFIER = ATTRIBUTES.register("climbing_speed_modifier", () -> new PercentageAttribute(
            prepend("climbing_speed_modifier"),
            1, 0, 1000
    ).setSyncable(true));

    public static final Holder<Attribute> ELYTRA_ACCELERATION_MODIFIER = ATTRIBUTES.register("elytra_acceleration_modifier", () -> new PercentageAttribute(
            prepend("elytra_acceleration_modifier"),
            1, 0, 1000
    ).setSyncable(true));

}
